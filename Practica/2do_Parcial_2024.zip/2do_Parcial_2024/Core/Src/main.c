/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PRIORIDAD_BAJA	((uint32_t) 1)
#define PRIORIDAD_MEDIA	((uint32_t) 2)
#define PRIORIDAD_ALTA	((uint32_t) 3)

#define Cantidad_Lecturas	((uint32_t) 3)
#define Cantidad_Muestras	((uint32_t) 8)

#define TEMP_THRESHOLD	((uint32_t) 1200)
#define HUM_THRESHOLD	((uint32_t) 2500)
#define PRES_THRESHOLD	((uint32_t) 1900)

#define DELAY_5S	((uint32_t) 5000)
#define DELAY_1S	((uint32_t) 1000)
#define DELAY_1Min	((uint32_t) 60000)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint32_t Lectura_ADC[Cantidad_Lecturas];
uint32_t Delay = DELAY_5S;
uint32_t Valores_Generales[3];
SemaphoreHandle_t Semaforo_ADC, Semaforo_EME;
QueueHandle_t Valores_Filtrados;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
void StartDefaultTask(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	BaseType_t Indicador = pdFALSE;
	xSemaphoreGiveFromISR(Semaforo_ADC, &Indicador);
	portYIELD_FROM_ISR(Indicador);
}

void Sensado_Valores (void *pvParameters)
{
	uint32_t Mediciones_Temp[Cantidad_Muestras],Mediciones_Hum[Cantidad_Muestras],Mediciones_Pres[Cantidad_Muestras];
	uint32_t Medicion = 0;
	uint32_t Temperatura = 0, Humedad = 0, Presion = 0;
	HAL_ADC_Start_DMA(&hadc1, Lectura_ADC, Cantidad_Lecturas);

	while(1)
	{
		xSemaphoreTake(Semaforo_ADC, portMAX_DELAY);

		Mediciones_Temp[Medicion] = Lectura_ADC[0];
		Mediciones_Hum[Medicion] = Lectura_ADC[1];
		Mediciones_Pres[Medicion] = Lectura_ADC[2];

		Temperatura = 0;
		Humedad = 0;
		Presion = 0;

		for(uint32_t i = 0 ; i < Cantidad_Muestras ; i++)
		{
			Temperatura += Mediciones_Temp[i];
			Humedad 	+= Mediciones_Hum[i];
			Presion 	+= Mediciones_Pres[i];
		}

		Temperatura /= Cantidad_Muestras;
		Humedad 	/= Cantidad_Muestras;
		Presion 	/= Cantidad_Muestras;

		xQueueSend(Valores_Filtrados, &Temperatura, 10);
		xQueueSend(Valores_Filtrados, &Humedad, 10);
		xQueueSend(Valores_Filtrados, &Presion, 10);

		vTaskDelay(Delay/portTICK_RATE_MS);

		Medicion++;
		Medicion %= Cantidad_Muestras;

		HAL_ADC_Start_DMA(&hadc1, Lectura_ADC, Cantidad_Lecturas);
	}
}

void Parseo_Valores (void *pvParameters)
{
	uint32_t Temp, Hum, Pres;
	while(1)
	{
		xQueueReceive(Valores_Filtrados, &Temp, portMAX_DELAY);
		xQueueReceive(Valores_Filtrados, &Hum, portMAX_DELAY);
		xQueueReceive(Valores_Filtrados, &Pres, portMAX_DELAY);

		if(Temp > TEMP_THRESHOLD)
			xSemaphoreGive(Semaforo_EME);
		else
		{
			HAL_GPIO_WritePin(Ventilacion_GPIO_Port, Ventilacion_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(LED_EMERGENCIA_GPIO_Port, LED_EMERGENCIA_Pin, GPIO_PIN_RESET);
			Delay = DELAY_5S;
		}

		if(Hum > HUM_THRESHOLD)
			HAL_GPIO_WritePin(Riego_GPIO_Port, Riego_Pin, GPIO_PIN_SET);
		else
			HAL_GPIO_WritePin(Riego_GPIO_Port, Riego_Pin, GPIO_PIN_RESET);

		if(Pres > PRES_THRESHOLD)
			HAL_GPIO_WritePin(Alarma_GPIO_Port, Alarma_Pin, GPIO_PIN_SET);
		else
			HAL_GPIO_WritePin(Alarma_GPIO_Port, Alarma_Pin, GPIO_PIN_RESET);

	}
}

void Emergencia (void *pvParameters)
{
	while(1)
	{
		xSemaphoreTake(Semaforo_EME,portMAX_DELAY);

		HAL_GPIO_WritePin(Ventilacion_GPIO_Port, Ventilacion_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LED_EMERGENCIA_GPIO_Port, LED_EMERGENCIA_Pin, GPIO_PIN_SET);
		Delay = DELAY_1S;

	}
}

void Tarea_Guardado (void *pvParameters)
{
	while(1)
	{
		// Entramos a sección crítica para evitar que el DMA nos pise el dato mientras leemos
		taskENTER_CRITICAL();
		Valores_Generales[0] = Lectura_ADC[0];
		Valores_Generales[1] = Lectura_ADC[1];
		Valores_Generales[2] = Lectura_ADC[2];
		taskEXIT_CRITICAL(); // Salimos de la sección crítica

		vTaskDelay(DELAY_1Min/ portTICK_RATE_MS);
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  xTaskCreate(Sensado_Valores, "Lectura de los Sensores", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + PRIORIDAD_MEDIA, NULL);
  xTaskCreate(Parseo_Valores, "Acciona las salidas", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + PRIORIDAD_BAJA, NULL);
  xTaskCreate(Emergencia, "Estado de Emergencia", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + PRIORIDAD_ALTA, NULL);
  xTaskCreate(Tarea_Guardado, "Tarea para guardar", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + PRIORIDAD_MEDIA, NULL);
  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  Semaforo_ADC = xSemaphoreCreateBinary();
  Semaforo_EME = xSemaphoreCreateBinary();

  xSemaphoreTake(Semaforo_ADC,0);
  xSemaphoreTake(Semaforo_EME,0);
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  Valores_Filtrados = xQueueCreate(3, sizeof(uint32_t));
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ENABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 3;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_4;
  sConfig.Rank = 3;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Ventilacion_Pin|Riego_Pin|Alarma_Pin|LED_EMERGENCIA_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Ventilacion_Pin Riego_Pin Alarma_Pin LED_EMERGENCIA_Pin */
  GPIO_InitStruct.Pin = Ventilacion_Pin|Riego_Pin|Alarma_Pin|LED_EMERGENCIA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {

  }
  /* USER CODE END 5 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

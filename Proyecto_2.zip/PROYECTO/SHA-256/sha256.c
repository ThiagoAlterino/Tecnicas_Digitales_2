#include "sha256.h"

//Declaracion de las constantes fijas de 32 bits
static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

//Macros para las funciones logicas
#define	SHR(x,n)	((x) >> (n))	//Desplaza los bits de x a la derecha n posiciones

/*	Choose:
 * 	Si el bit de x es 1, elige el bit correspondiente de y.
 * 	Si el bit de x es 0, elige el bit correspondiente de z.*/
#define	CH(x,y,z)	(((x) & (y)) ^ (~(x)&(z)))

/*	Mayority:
 * 	Realiza una votacion de "mayoria" bit a bit entre tres valores:
 * 		Si dos de tres bits son 1, el resultado es 1
 * 		Si dos de tres bits son 0, el resultado es 0 */
#define	MAJ(x,y,z)	(((x)&(y)) ^ ((x)&(z)) ^ ((y)&(z)))

/*EP0 y EP1 se usan en el bucle principal de compresion sobre las
 * variables de estado en cada una de las 64 rondas.
 *
 * Toman un entero de 32 bits, lo rotan circularmente a tres velocidades
 * (2, 13 y 22 posiciones) y combinan las tres rotadas con una
 * operacion XOR(^)*/
#define	EP0(x)		(ROTR(x,2) ^ ROTR(x,13) ^ ROTR(x,22))
#define	EP1(x)		(ROTR(x,6) ^ ROTR(x,11) ^ ROTR(x,25))

/* SIG0 y SIG1 se usan en la extencion del mensaje.
 *
 * Cuando le pasamos 16 palabras de datos al SHA-256, el algoritmo necesita
 * estirar esas 16 palabras a 64 palabras para alimentar las 64 rondas.
 * Combinan dos rotaciones con un desplazamiento rigido para generar esas
 * palabras nuevas de forma impredecible.*/
#define	SIG0(x)		(ROTR(x,7) ^ ROTR(x,18) ^ SHR(x,3))
#define	SIG1(x)		(ROTR(x,17) ^ ROTR(x,19) ^ SHR(x,10))

void sha256_init(SHA256_ctx_t *ctx)
{
	ctx->datalen = 0;
	ctx->bitlen = 0;

	ctx->state[0] = 0x6a09e667;
	ctx->state[1] = 0xbb67ae85;
	ctx->state[2] = 0x3c6ef372;
	ctx->state[3] = 0xa54ff53a;
	ctx->state[4] = 0x510e527f;
	ctx->state[5] = 0x9b05688c;
	ctx->state[6] = 0x1f83d9ab;
	ctx->state[7] = 0x5be0cd19;
}

static void sha256_transform(SHA256_ctx_t *ctx, const uint8_t data[])
{
	/*	Tomamos los 64 bytes de entrada y los convertimos en un array de 64 palabras de 32 bits.
	 *
	 * 	SHA-256 exige que los datos sean guardados en Big-Endian,
	 * 	pero la arquitectura M4 guarda los enteros en Little-Endian.
	 * 	Por esto empaquetamos manualmente 4 bytes uint8_t en 1 palabra uint32_t*/

	uint32_t W[64];
	uint32_t i, j;

	for(i = 0, j = 0 ; i < 16 ; i++, j += 4 )
	{
		W[i] = (((uint32_t)data[j] << 24) | ((uint32_t)data[j+1] << 16) | ((uint32_t)data[j+2] << 8) | (uint32_t)data[j+3]);
	}

	/*	Los 64 bytes se guardaron de a 4 bytes en 1 palabra uint32_t, entonces tenemos 16 palabras.
	 * 	Para generar las 48 palabras restantes se mezclan las anteriores usando las macros SIG0 y SIG1*/
	for(i = 16 ; i < 64 ; i++)
	{
		W[i] = SIG1(W[i-2]) + W[i-7] + SIG0(W[i-15]) + W[i-16];
	}

	/* Estructura base: Red Feistel Desbalanceada
	 * En SHA-256 los 256 bits de estado se dividen en 8 registros de 32 bits.
	 * T1 y T2 son las funciones de ronda (Funciones de Feistel) que generar la
	 * no linealidad necesaria para romper cualquier patron*/
	uint32_t a,b,c,d,e,f,g,h,T1,T2;

	a = ctx->state[0];
	b = ctx->state[1];
	c = ctx->state[2];
	d = ctx->state[3];
	e = ctx->state[4];
	f = ctx->state[5];
	g = ctx->state[6];
	h = ctx->state[7];

	for(i=0 ; i < 64 ; i++)
	{
		T1 = h + EP1(e) + CH(e,f,g) + K[i] + W[i];
		T2 = EP0(a) + MAJ(a,b,c);
	}

	h = g;
	g = f;
	f = e;
	e = d + T1;
	d = c;
	c = b;
	b = a;
	a = T1 + T2;

	ctx->state[0] += a;
	ctx->state[1] += b;
	ctx->state[2] += c;
	ctx->state[3] += d;
	ctx->state[4] += e;
	ctx->state[5] += f;
	ctx->state[6] += g;
	ctx->state[7] += h;
}

void sha256_update(SHA256_ctx_t *ctx, const uint8_t *data, size_t len)
{
	size_t i;
	for(i = 0; i < len ; i++)
	{
		ctx->buffer[ctx->datalen] = data[i];
		(ctx->datalen)++;

		if( ctx->datalen == 64)
		{
			ctx->bitlen += 512;
			ctx->datalen = 0;
			sha256_transform(ctx, ctx->buffer);
		}
	}
}

void sha256_final(SHA256_ctx_t *ctx, uint8_t *hash)
{
	uint64_t total_bits = ctx->bitlen + (ctx->datalen * 8);

	ctx->buffer[ctx->datalen] = 0x80;
	ctx->datalen++;

	if(ctx->datalen <= 56)
	{
		for( ; ctx->datalen < 56 ; (ctx->datalen)++)
			ctx->buffer[ctx->datalen] = 0x00;
	}
	else
	{
		for( ; ctx->datalen < 64 ; (ctx->datalen)++)
					ctx->buffer[ctx->datalen] = 0x00;
		ctx->bitlen += 512;
		ctx->datalen = 0;
		sha256_transform(ctx, ctx->buffer);

		for(uint32_t i = 0; i < 56 ; i++)
			ctx->buffer[i] = 0x00;
	}

	for(uint32_t i = 0,n = 56 ; i < 8 ; i++, n-=8)
		ctx->buffer[(56+i)] = (0xFF & (total_bits >> n));

	sha256_transform(ctx, ctx->buffer);

	for(uint32_t i = 0, j = 0 ; i < 8 ; i++ )
		for(uint32_t n = 0; n <=24 ; j++, n += 8)
			hash[j] = (0xFF & ((ctx->state[i]) >> (24-n)));
}


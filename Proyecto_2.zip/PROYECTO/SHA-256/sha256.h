/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : sha256.h
  * @brief          : sha256 struct
  ******************************************************************************
  ******************************************************************************
  */
/* USER CODE END Header */

#ifndef SHA256_H
#define SHA256_H

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stddef.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef struct
{
    uint32_t state[8];	//H0 a H7 (Estado Interno)
    uint8_t buffer[64];	//Bloque actual de 512 bits
    uint32_t datalen;	//Bytes actualmente cargados en el buffer (0 a 63)
    uint64_t bitlen;
}SHA256_ctx_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define ROTR(x,n)	(((x) >> (n))|((x) << (32-(n))))
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/

/* USER CODE BEGIN PFP */
void sha256_init(SHA256_ctx_t *ctx);
void sha256_update(SHA256_ctx_t *ctx, const uint8_t *data, size_t len);
void sha256_final(SHA256_ctx_t *ctx, uint8_t *hash);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

#endif /* SHA256_H */

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Definicion de estados para la maquina principal
#define	NORMAL		((uint32_t) 0)
#define	EMERGENCIA	((uint32_t) 1)
#define	FALLO		((uint32_t) 2)

// Definicion de estados para la maquina de purga
#define	PURGA_ON_A	((uint32_t) 3)
#define	PURGA_ON_B 	((uint32_t) 4)
#define	PURGA_OFF 	((uint32_t) 5)

// Definicion de estados para la maquina del anti rebote
#define	REBOTE_UP	((uint32_t) 6)
#define	REBOTE_DOWN	((uint32_t) 7)
#define REBOTE_OFF	((uint32_t) 8)

// Definiciones para el PWM
#define PWM_MAX		((uint32_t) 875)
#define PWM_MIN 	((uint32_t) 250)
#define PWM_DELTA	((uint32_t) 125)
#define TIM6_Periodo	((uint32_t) 45000)

// Como el TIM2 y el TIM3 estan configurados para interrumpir cada 0.5ms se define una constante que multiplica a MS_VALVULAS
#define K_TIM2		((uint32_t) 2)
#define MS_VALVULAS	((uint32_t) (1500*K_TIM2))	//Siendo 1500 lo requirido en el enunciado

/* Como el TIM4 esta configurado para interrumpir cada 0.5ms
se define una constante igual a 2 para correr la base de tiempo a 1ms en la configuracion de los #define*/
#define K_TIM4				((uint32_t) 2)
#define MS_INTERRUP_REBOTE	((uint32_t) (2*K_TIM4))		//Siendo 2 los milisegundos a los que quiero qu interrumpa el timer del antirebote
#define CNTR_REBOTE_MAX		(((uint32_t) 25))		//Como interrumpe cada 2ms, CNTR_REBOTE_MAX es igual al dato que impone el enunciado sobre 2


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
uint32_t Duty_Cycle = 500;
uint32_t Estado_Principal = NORMAL;
uint32_t Estado_Purga = PURGA_OFF;
uint32_t Estado_Rebote = REBOTE_OFF;
uint32_t Cntr_Anti_Rebote = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM7_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if((htim->Instance) == TIM6)
	{
		// Timer del PWM que impone el periodo al PWM de la maquina principal
		Estado_Principal = NORMAL;
		//Prender la Bomba
		HAL_GPIO_WritePin(Bomba_GPIO_Port, Bomba_Pin, GPIO_PIN_SET);

		//Configurar el TIM7 (Counter = 0 y Autoregister ~ PWM)
		__HAL_TIM_SET_COUNTER(&htim7,0);
		__HAL_TIM_SET_AUTORELOAD(&htim7,(Duty_Cycle * TIM6_Periodo/1000));
		HAL_TIM_Base_Start_IT(&htim7);

	}

	if((htim->Instance) == TIM7)
	{
		HAL_TIM_Base_Stop_IT(&htim7);
		HAL_GPIO_WritePin(Bomba_GPIO_Port, Bomba_Pin, GPIO_PIN_RESET);
	}

	if((htim->Instance) == TIM2)
	{
		// Timer de la maquina de purga para la Valvula A
		// Apago el TIM2
		HAL_TIM_Base_Stop_IT(&htim2);

		// Apago Valvula A y Prendo Valvula B
		HAL_GPIO_WritePin(Bypass_A_GPIO_Port, Bypass_A_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(Bypass_B_GPIO_Port, Bypass_B_Pin, GPIO_PIN_SET);

		Estado_Purga = PURGA_ON_B;

		//Configurar el TIM3 (Counter = 0 y Autoregister ~ PWM)
		__HAL_TIM_SET_COUNTER(&htim3,0);
		__HAL_TIM_SET_AUTORELOAD(&htim3,MS_VALVULAS);
		HAL_TIM_Base_Start_IT(&htim3);
	}

	if((htim->Instance) == TIM3)
	{
		// Timer de la maquina de purga para la Valvula B
		HAL_TIM_Base_Stop_IT(&htim3);
		HAL_GPIO_WritePin(Bypass_B_GPIO_Port, Bypass_B_Pin, GPIO_PIN_RESET);
		Estado_Purga = PURGA_OFF;
	}

	if((htim->Instance) == TIM4)
	{
		// Timer para la maquina anti rebote

		// Pregunto por el boton up y aumento el contador
		if(HAL_GPIO_ReadPin(PWM_UP_GPIO_Port, PWM_UP_Pin) == GPIO_PIN_RESET && Estado_Rebote == REBOTE_UP)
			Cntr_Anti_Rebote++;
		else if(Cntr_Anti_Rebote > 0)
			Cntr_Anti_Rebote--;

		// Pregunto por el boton down y aumento el contador
		if(HAL_GPIO_ReadPin(PWM_DOWN_GPIO_Port, PWM_DOWN_Pin) == GPIO_PIN_RESET && Estado_Rebote == REBOTE_DOWN)
			Cntr_Anti_Rebote++;
		else if(Cntr_Anti_Rebote > 0)
			Cntr_Anti_Rebote--;

		if(Cntr_Anti_Rebote == CNTR_REBOTE_MAX)
		{
			Cntr_Anti_Rebote = 0;

			if(Duty_Cycle < PWM_MAX && Estado_Rebote == REBOTE_UP)
				Duty_Cycle += PWM_DELTA;

			if(Duty_Cycle > PWM_MIN && Estado_Rebote == REBOTE_DOWN)
				Duty_Cycle -= PWM_DELTA;

			Estado_Rebote = REBOTE_OFF;
			HAL_TIM_Base_Stop_IT(&htim4);
		}
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(Estado_Principal != FALLO)
	{
		if(GPIO_Pin == Emergencia_Pin)
		{
			if(HAL_GPIO_ReadPin(Emergencia_GPIO_Port,Emergencia_Pin) == GPIO_PIN_RESET)
			{
				// Comienza la rutina de emergencia
				// Apago el PWM
				HAL_TIM_Base_Stop_IT(&htim6);
				HAL_TIM_Base_Stop_IT(&htim7);
				HAL_GPIO_WritePin(Bomba_GPIO_Port, Bomba_Pin, GPIO_PIN_RESET);

				// Apago la purga
				HAL_TIM_Base_Stop_IT(&htim2);
				HAL_TIM_Base_Stop_IT(&htim3);
				HAL_GPIO_WritePin(Bypass_A_GPIO_Port, Bypass_A_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(Bypass_B_GPIO_Port, Bypass_B_Pin, GPIO_PIN_RESET);

				Estado_Principal = EMERGENCIA;
			}
			else
			{
				// Sale de la rutina de emergencia y reestablece las maquinas principal y de purga
				// Prendo el PWM
				HAL_TIM_Base_Start_IT(&htim6);

				// Continuo la purga si es que estaba en purga
				if(Estado_Purga != PURGA_OFF)
				{
					if(Estado_Purga == PURGA_ON_A)
					{
						HAL_GPIO_WritePin(Bypass_A_GPIO_Port, Bypass_A_Pin, GPIO_PIN_SET);
						HAL_TIM_Base_Start_IT(&htim2);
					}
					else
					{
						HAL_GPIO_WritePin(Bypass_B_GPIO_Port, Bypass_B_Pin, GPIO_PIN_SET);
						HAL_TIM_Base_Start_IT(&htim3);
					}
				}
				Estado_Principal = NORMAL;
			}
		}

		if(GPIO_Pin == SPA_Pin)
		{
			// SPA comienza la rutina de purga
			// Prendo Valvula A
			HAL_GPIO_WritePin(Bypass_A_GPIO_Port, Bypass_A_Pin, GPIO_PIN_SET);
			Estado_Purga = PURGA_ON_A;

			//Configurar el TIM2 (Counter = 0 y Autoregister ~ PWM)
			__HAL_TIM_SET_COUNTER(&htim2,0);
			__HAL_TIM_SET_AUTORELOAD(&htim2,MS_VALVULAS);
			HAL_TIM_Base_Start_IT(&htim2);
		}

		if(GPIO_Pin == SPB_Pin)
		{
			// SPB Bloquea la maquina principal, permite que termine la maquina de purga
			Estado_Principal = FALLO;
			// Apago el PWM
			HAL_TIM_Base_Stop_IT(&htim6);
			HAL_TIM_Base_Stop_IT(&htim7);
			// Apago la bomba
			HAL_GPIO_WritePin(Bomba_GPIO_Port, Bomba_Pin, GPIO_PIN_RESET);
		}

		if(GPIO_Pin == PWM_UP_Pin && Estado_Principal == NORMAL)
		{
			// Comienza la rutina anti rebote para el pulsador up
			Estado_Rebote = REBOTE_UP;
			__HAL_TIM_SET_COUNTER(&htim4,0);
			__HAL_TIM_SET_AUTORELOAD(&htim4,MS_INTERRUP_REBOTE);
			HAL_TIM_Base_Start_IT(&htim4);
		}

		if(GPIO_Pin == PWM_DOWN_Pin && Estado_Principal == NORMAL)
		{
			// Comienza la rutina anti rebote para el pulsador down
			Estado_Rebote = REBOTE_DOWN;
			__HAL_TIM_SET_COUNTER(&htim4,0);
			__HAL_TIM_SET_AUTORELOAD(&htim4,MS_INTERRUP_REBOTE);
			HAL_TIM_Base_Start_IT(&htim4);
		}
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM6_Init();
  MX_TIM7_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_Base_Start_IT(&htim6);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 90;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 45000;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 45000;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 45000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 0;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 45000;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 45000;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 65535;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, Bypass_A_Pin|Bypass_B_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Bomba_GPIO_Port, Bomba_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SPA_Pin SPB_Pin */
  GPIO_InitStruct.Pin = SPA_Pin|SPB_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PWM_UP_Pin PWM_DOWN_Pin */
  GPIO_InitStruct.Pin = PWM_UP_Pin|PWM_DOWN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Bypass_A_Pin Bypass_B_Pin */
  GPIO_InitStruct.Pin = Bypass_A_Pin|Bypass_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : Bomba_Pin */
  GPIO_InitStruct.Pin = Bomba_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Bomba_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Emergencia_Pin */
  GPIO_InitStruct.Pin = Emergencia_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(Emergencia_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
